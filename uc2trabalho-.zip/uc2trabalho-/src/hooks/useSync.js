import {
  useEffect,
} from 'react';

import useNetwork from './useNetwork';

import { sincronizarDados } from '../services/syncService';

export default function useSync(
  onSync
) {
  const online = useNetwork();

  async function sync() {
    await sincronizarDados();

    if (onSync) {
      onSync();
    }
  }

  useEffect(() => {
    if (online) {
      sync();
    }
  }, [online]);

  return {
    sync,
    online,
  };
}