import { useEffect, useState } from 'react';
import NetInfo from '@react-native-community/netinfo';

export default function useNetwork() {
  const [online, setOnline] = useState(false);

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener((state) => {
      const conectado =
        state.isConnected === true &&
        state.isInternetReachable !== false;

      setOnline(conectado);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  return online;
}