import React from 'react';
import { Text, View } from 'react-native';

export default function StatusBadge({ status }) {
  let corFundo = '#F59E0B';
  let corTexto = '#FFFFFF';

  if (status === 'SINCRONIZADO') {
    corFundo = '#10B981';
  }

  if (status === 'FALHA') {
    corFundo = '#EF4444';
  }

  if (status === 'SINCRONIZANDO') {
    corFundo = '#0EA5E9';
  }

  return (
    <View
      style={{
        alignSelf: 'flex-start',
        backgroundColor: corFundo,
        paddingVertical: 6,
        paddingHorizontal: 12,
        borderRadius: 999,
      }}
    >
      <Text
        style={{
          color: corTexto,
          fontWeight: 'bold',
          fontSize: 12,
        }}
      >
        {status}
      </Text>
    </View>
  );
}