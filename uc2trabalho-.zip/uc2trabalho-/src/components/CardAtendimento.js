import React from 'react';
import { View, Text, TouchableOpacity, Alert } from 'react-native';

import { supabase } from '../services/supabase';
import { deleteAtendimento } from '../services/storage';

import StatusBadge from './StatusBadge';

export default function CardAtendimento({ item, atualizar }) {
  async function excluir() {
    const confirmar = window.confirm
      ? window.confirm('Deseja excluir este atendimento?')
      : true;

    if (!confirmar) return;

    try {
      const { error } = await supabase
        .from('atendimentos')
        .delete()
        .eq('id', item.id);

      if (error) {
        throw error;
      }

      await deleteAtendimento(item.id);
      atualizar();
    } catch (error) {
      console.log('Erro ao excluir:', error);

      Alert.alert(
        'Erro',
        'Não foi possível excluir: ' + error.message
      );
    }
  }

  return (
    <View
      style={{
        backgroundColor: '#FFFFFF',
        padding: 18,
        borderRadius: 18,
        marginBottom: 16,
        borderWidth: 1,
        borderColor: '#E5E7EB',
        shadowColor: '#000',
        shadowOpacity: 0.08,
        shadowRadius: 8,
        shadowOffset: { width: 0, height: 4 },
        elevation: 4,
      }}
    >
      <Text
        style={{
          fontSize: 20,
          fontWeight: 'bold',
          color: '#111827',
          marginBottom: 6,
        }}
      >
        {item.nome}
      </Text>

      <Text
        style={{
          fontSize: 14,
          color: '#2563EB',
          fontWeight: 'bold',
          marginBottom: 10,
        }}
      >
        CPF: {item.cpf}
      </Text>

      <Text
        style={{
          fontSize: 15,
          color: '#374151',
          lineHeight: 22,
          marginBottom: 12,
        }}
      >
        {item.descricao}
      </Text>

      <Text
        style={{
          color: '#6B7280',
          fontSize: 12,
          marginBottom: 12,
        }}
      >
        {new Date(item.data).toLocaleString()}
      </Text>

      <StatusBadge status={item.status} />

      <TouchableOpacity
        onPress={excluir}
        style={{
          backgroundColor: '#EF4444',
          marginTop: 15,
          padding: 13,
          borderRadius: 12,
        }}
      >
        <Text
          style={{
            color: '#FFFFFF',
            textAlign: 'center',
            fontWeight: 'bold',
            fontSize: 15,
          }}
        >
          Excluir atendimento
        </Text>
      </TouchableOpacity>
    </View>
  );
}