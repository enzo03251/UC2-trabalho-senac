import React, { useEffect, useState } from 'react';

import {
  View,
  Text,
  ScrollView,
} from 'react-native';

import { getAtendimentos } from '../services/storage';

export default function PedidosScreen() {
  const [total, setTotal] = useState(0);
  const [pendentes, setPendentes] = useState(0);
  const [sincronizados, setSincronizados] = useState(0);
  const [falhas, setFalhas] = useState(0);
  const [alta, setAlta] = useState(0);
  const [media, setMedia] = useState(0);
  const [baixa, setBaixa] = useState(0);

  async function carregarDados() {
    const lista = await getAtendimentos();

    setTotal(lista.length);

    setPendentes(
      lista.filter(item => item.status === 'PENDENTE').length
    );

    setSincronizados(
      lista.filter(item => item.status === 'SINCRONIZADO').length
    );

    setFalhas(
      lista.filter(item => item.status === 'FALHA').length
    );

    setAlta(
      lista.filter(item => item.prioridade === 'alta').length
    );

    setMedia(
      lista.filter(item => item.prioridade === 'média').length
    );

    setBaixa(
      lista.filter(item => item.prioridade === 'baixa').length
    );
  }

  useEffect(() => {
    carregarDados();
  }, []);

  function Card({ titulo, valor, cor, subtitulo }) {
    return (
      <View style={styles.card}>
        <View style={styles.cardContent}>
          <View>
            <Text style={styles.cardTitulo}>{titulo}</Text>

            <Text style={styles.cardValor}>{valor}</Text>

            <Text style={styles.cardSubtitulo}>{subtitulo}</Text>
          </View>

          <View style={[styles.bolinha, { backgroundColor: cor }]} />
        </View>
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}>
      <Text style={styles.titulo}>Resumo dos pedidos</Text>

      <Text style={styles.subtitulo}>
        Acompanhe os registros salvos no sistema
      </Text>

      <Card
        titulo="Total de registros"
        valor={total}
        cor="#3B82F6"
        subtitulo="Todos os atendimentos cadastrados"
      />

      <Card
        titulo="Pendentes"
        valor={pendentes}
        cor="#F59E0B"
        subtitulo="Aguardando sincronização"
      />

      <Card
        titulo="Sincronizados"
        valor={sincronizados}
        cor="#10B981"
        subtitulo="Enviados com sucesso"
      />

      <Card
        titulo="Falhas"
        valor={falhas}
        cor="#EF4444"
        subtitulo="Precisam de revisão"
      />

      <Text style={styles.secao}>Prioridades</Text>

      <Card
        titulo="Alta prioridade"
        valor={alta}
        cor="#DC2626"
        subtitulo="Sincronizam primeiro"
      />

      <Card
        titulo="Média prioridade"
        valor={media}
        cor="#F59E0B"
        subtitulo="Sincronizam depois das altas"
      />

      <Card
        titulo="Baixa prioridade"
        valor={baixa}
        cor="#10B981"
        subtitulo="Sincronizam por último"
      />
    </ScrollView>
  );
}

const styles = {
  container: {
    flex: 1,
    backgroundColor: '#F7F5F2',
  },
  content: {
    padding: 24,
    paddingTop: 52,
  },
  titulo: {
    fontSize: 30,
    fontWeight: '500',
    color: '#2C2C2A',
    marginBottom: 4,
  },
  subtitulo: {
    fontSize: 15,
    color: '#888780',
    marginBottom: 24,
  },
  secao: {
    fontSize: 12,
    color: '#B4B2A9',
    fontWeight: '500',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    marginTop: 12,
    marginBottom: 12,
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 18,
    marginBottom: 14,
    borderWidth: 0.5,
    borderColor: '#E8E6E3',
  },
  cardContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  cardTitulo: {
    fontSize: 14,
    color: '#7A7A7A',
    marginBottom: 6,
  },
  cardValor: {
    fontSize: 34,
    fontWeight: '700',
    color: '#222',
  },
  cardSubtitulo: {
    fontSize: 13,
    color: '#9A9A9A',
    marginTop: 4,
  },
  bolinha: {
    width: 14,
    height: 14,
    borderRadius: 7,
  },
};