import React, { useState } from 'react';

import {
  View,
  TextInput,
  TouchableOpacity,
  Text,
  Alert,
  ScrollView,
} from 'react-native';

import { saveAtendimento } from '../services/storage';

import { generateId } from '../utils/generateId';

import { STATUS } from '../utils/statuses';

export default function NovoAtendimentoScreen({ navigation }) {
  const [nome, setNome] = useState('');
  const [cpf, setCpf] = useState('');
  const [descricao, setDescricao] = useState('');
  const [categoria, setCategoria] = useState('');
  const [prioridade, setPrioridade] = useState('');

  const categorias = [
    'alimentação',
    'saúde',
    'educação',
    'assistência social',
  ];

  const prioridades = ['alta', 'média', 'baixa'];

  async function salvar() {
    if (!nome || !cpf || !descricao || !categoria || !prioridade) {
      Alert.alert('Erro', 'Preencha todos os campos');
      return;
    }

    const novo = {
      id: generateId(),
      nome,
      cpf,
      descricao,
      categoria,
      prioridade,
      data: new Date().toISOString(),
      status: STATUS.PENDENTE,
    };

    await saveAtendimento(novo);

    Alert.alert('Sucesso', 'Atendimento salvo offline');

    navigation.goBack();
  }

  function BotaoOpcao({ texto, selecionado, onPress }) {
    return (
      <TouchableOpacity
        onPress={onPress}
        style={[
          styles.opcao,
          selecionado && styles.opcaoSelecionada,
        ]}>
        <Text
          style={[
            styles.opcaoTexto,
            selecionado && styles.opcaoTextoSelecionado,
          ]}>
          {texto}
        </Text>
      </TouchableOpacity>
    );
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}>
      <Text style={styles.titulo}>Novo atendimento</Text>

      <Text style={styles.subtitulo}>
        Preencha as informações do atendido
      </Text>

      <Text style={styles.label}>Nome do atendido</Text>
      <TextInput
        placeholder="Digite o nome"
        value={nome}
        onChangeText={setNome}
        placeholderTextColor="#888780"
        style={styles.input}
      />

      <Text style={styles.label}>CPF</Text>
      <TextInput
        placeholder="Digite o CPF"
        value={cpf}
        onChangeText={setCpf}
        keyboardType="numeric"
        placeholderTextColor="#888780"
        style={styles.input}
      />

      <Text style={styles.label}>Categoria</Text>
      <View style={styles.opcoesArea}>
        {categorias.map(item => (
          <BotaoOpcao
            key={item}
            texto={item}
            selecionado={categoria === item}
            onPress={() => setCategoria(item)}
          />
        ))}
      </View>

      <Text style={styles.label}>Prioridade</Text>
      <View style={styles.opcoesArea}>
        {prioridades.map(item => (
          <BotaoOpcao
            key={item}
            texto={item}
            selecionado={prioridade === item}
            onPress={() => setPrioridade(item)}
          />
        ))}
      </View>

      <Text style={styles.label}>Descrição</Text>
      <TextInput
        placeholder="Descreva o atendimento"
        value={descricao}
        onChangeText={setDescricao}
        multiline
        numberOfLines={4}
        textAlignVertical="top"
        placeholderTextColor="#888780"
        style={[styles.input, styles.textArea]}
      />

      <TouchableOpacity onPress={salvar} style={styles.btnSalvar}>
        <Text style={styles.btnSalvarTexto}>Salvar atendimento</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = {
  container: {
    flex: 1,
    backgroundColor: '#F7F5F2',
  },
  content: {
    padding: 24,
    paddingTop: 52,
  },
  titulo: {
    fontSize: 32,
    fontWeight: '500',
    color: '#2C2C2A',
    marginBottom: 4,
  },
  subtitulo: {
    fontSize: 15,
    color: '#888780',
    marginBottom: 24,
  },
  label: {
    fontSize: 14,
    color: '#444441',
    marginBottom: 8,
    marginTop: 10,
  },
  input: {
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 14,
    borderWidth: 0.5,
    borderColor: '#E8E6E3',
    color: '#2C2C2A',
    marginBottom: 8,
  },
  textArea: {
    minHeight: 110,
  },
  opcoesArea: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 8,
  },
  opcao: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    paddingVertical: 9,
    paddingHorizontal: 14,
    borderWidth: 0.5,
    borderColor: '#E8E6E3',
  },
  opcaoSelecionada: {
    backgroundColor: '#2C2C2A',
    borderColor: '#2C2C2A',
  },
  opcaoTexto: {
    color: '#444441',
    fontSize: 13,
  },
  opcaoTextoSelecionado: {
    color: '#F7F5F2',
  },
  btnSalvar: {
    backgroundColor: '#2C2C2A',
    borderRadius: 14,
    padding: 16,
    marginTop: 18,
    alignItems: 'center',
  },
  btnSalvarTexto: {
    color: '#F7F5F2',
    fontSize: 15,
    fontWeight: '500',
  },
};