import React, { useEffect, useState, useCallback } from 'react';

import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  TextInput,
} from 'react-native';

import { getAtendimentos } from '../services/storage';

import CardAtendimento from '../components/CardAtendimento';

import useSync from '../hooks/useSync';

export default function HomeScreen({ navigation }) {
  const [dados, setDados] = useState([]);
  const [busca, setBusca] = useState('');
  const [loading, setLoading] = useState(false);

  const carregar = useCallback(async () => {
    const lista = await getAtendimentos();

    const pesoPrioridade = {
      alta: 1,
      média: 2,
      baixa: 3,
    };

    const pendentes = lista
      .filter((item) => item.status !== 'SINCRONIZADO')
      .sort((a, b) => {
        return (
          (pesoPrioridade[a.prioridade] || 4) -
          (pesoPrioridade[b.prioridade] || 4)
        );
      });

    setDados(pendentes);
  }, []);

  const { sync, online } = useSync(carregar);

  async function handleSync() {
    setLoading(true);

    try {
      await sync();
      await carregar();
    } catch (error) {
      console.log('Erro ao sincronizar:', error);
      alert('Erro ao sincronizar os dados.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', carregar);
    return unsubscribe;
  }, [navigation, carregar]);

  const dadosFiltrados = dados.filter((item) =>
    item.nome.toLowerCase().includes(busca.toLowerCase())
  );

  const hoje = new Date().toLocaleDateString('pt-BR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  });

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.data}>{hoje}</Text>
          <Text style={styles.titulo}>Atendimentos</Text>
          <Text style={styles.subtitulo}>
            {dadosFiltrados.length}{' '}
            {dadosFiltrados.length === 1 ? 'pendente' : 'pendentes'}
          </Text>
        </View>

        <View
          style={[
            styles.statusBadge,
            { borderColor: online ? '#D1FAE5' : '#FEE2E2' },
          ]}>
          <View
            style={[
              styles.statusDot,
              { backgroundColor: online ? '#34D399' : '#EF4444' },
            ]}
          />
          <Text style={styles.statusText}>{online ? 'Online' : 'Offline'}</Text>
        </View>
      </View>

      <TextInput
        placeholder="Buscar pelo nome"
        value={busca}
        onChangeText={setBusca}
        placeholderTextColor="#888780"
        style={styles.inputBusca}
      />

      <TouchableOpacity
        onPress={() => navigation.navigate('NovoAtendimento')}
        style={styles.btnPrimary}>
        <Text style={styles.btnPrimaryText}>Novo atendimento</Text>
        <Text style={styles.btnPrimaryIcon}>+</Text>
      </TouchableOpacity>

      <View style={styles.btnRow}>
        <TouchableOpacity
          onPress={() => navigation.navigate('Pedidos')}
          style={styles.btnSecondary}>
          <Text style={styles.btnSecondaryText}>Pedidos</Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={handleSync}
          disabled={loading}
          style={[styles.btnSecondary, loading && styles.btnDisabled]}>
          <Text style={styles.btnSecondaryText}>
            {loading ? 'Sincronizando...' : 'Sincronizar'}
          </Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.secaoLabel}>Pendentes por prioridade</Text>


      <FlatList
        data={dadosFiltrados}
        keyExtractor={(item) => String(item.id)}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 32 }}
        renderItem={({ item }) => (
          <CardAtendimento item={item} atualizar={carregar} />
        )}
        ListEmptyComponent={
          <View style={styles.emptyCard}>
            <Text style={styles.emptyText}>Nenhum atendimento encontrado.</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = {
  container: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 52,
    backgroundColor: '#F7F5F2',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 18,
  },
  data: {
    fontSize: 13,
    color: '#888780',
    marginBottom: 6,
  },
  titulo: {
    fontSize: 32,
    fontWeight: '500',
    color: '#2C2C2A',
    marginBottom: 4,
  },
  subtitulo: {
    fontSize: 15,
    color: '#888780',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderWidth: 0.5,
    marginTop: 4,
  },
  statusDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  statusText: {
    fontSize: 12,
    color: '#444441',
  },
  inputBusca: {
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 14,
    borderWidth: 0.5,
    borderColor: '#E8E6E3',
    marginBottom: 12,
    color: '#2C2C2A',
  },
  btnPrimary: {
    backgroundColor: '#2C2C2A',
    borderRadius: 14,
    padding: 16,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  btnPrimaryText: {
    color: '#F7F5F2',
    fontSize: 15,
    fontWeight: '500',
  },
  btnPrimaryIcon: {
    color: '#888780',
    fontSize: 20,
  },
  btnRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 28,
  },
  btnSecondary: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 14,
    borderWidth: 0.5,
    borderColor: '#E8E6E3',
    alignItems: 'center',
  },
  btnSecondaryText: {
    color: '#444441',
    fontSize: 14,
  },
  btnDisabled: {
    opacity: 0.5,
  },
  secaoLabel: {
    fontSize: 12,
    color: '#B4B2A9',
    fontWeight: '500',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    marginBottom: 12,
  },
  emptyCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    borderWidth: 0.5,
    borderColor: '#E8E6E3',
    alignItems: 'center',
  },
  emptyText: {
    color: '#888780',
    fontSize: 14,
  },
};
