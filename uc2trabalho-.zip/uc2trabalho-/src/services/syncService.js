import { getAtendimentos, updateAtendimentos } from './storage';

import { supabase } from './supabase';

import { STATUS } from '../utils/statuses';

export async function sincronizarDados() {
  const lista = await getAtendimentos();

  for (let item of lista) {
    if (item.status !== STATUS.SINCRONIZADO) {
      try {
        item.status = STATUS.SINCRONIZANDO;
        await updateAtendimentos(lista);

        const atendimentoParaEnviar = {
          id: item.id,
          nome: item.nome,
          cpf: item.cpf,
          descricao: item.descricao,
          categoria: item.categoria || '',
          prioridade: item.prioridade || '',
          data: item.data,
          status: STATUS.SINCRONIZADO,
        };

        console.log('ENVIANDO:', atendimentoParaEnviar);

        const { data, error } = await supabase
          .from('atendimentos')
          .upsert([atendimentoParaEnviar])
          .select();

        console.log('RESPOSTA SUPABASE:', { data, error });

        if (error) {
          throw error;
        }

        item.status = STATUS.SINCRONIZADO;
      } catch (e) {
        console.log('ERRO AO SINCRONIZAR:', e);
        alert('Erro ao sincronizar: ' + e.message);

        item.status = STATUS.FALHA;
      }

      await updateAtendimentos(lista);
    }
  }
}
