import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL =
  'https://sdwpdndcnvjcdncdnrdc.supabase.co';

const SUPABASE_KEY =
  'sb_publishable_YV9YF_f1ow9H8cfDhNHeSA_TJU3KL0B';

export const supabase = createClient(
  SUPABASE_URL,
  SUPABASE_KEY
);