import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = '@atendimentos';

export async function getAtendimentos() {
  const data = await AsyncStorage.getItem(KEY);

  return data ? JSON.parse(data) : [];
}

export async function saveAtendimento(atendimento) {
  const lista = await getAtendimentos();

  const novaLista = [...lista, atendimento];

  await AsyncStorage.setItem(
    KEY,
    JSON.stringify(novaLista)
  );
}

export async function updateAtendimentos(lista) {
  await AsyncStorage.setItem(
    KEY,
    JSON.stringify(lista)
  );
}
export async function deleteAtendimento(
  id
) {
  const lista =
    await getAtendimentos();

  const novaLista = lista.filter(
    item => item.id !== id
  );

  await AsyncStorage.setItem(
    KEY,
    JSON.stringify(novaLista)
  );
}