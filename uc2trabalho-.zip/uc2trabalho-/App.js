import React from 'react';

import { NavigationContainer } from '@react-navigation/native';

import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from './src/screens/HomeScreen';
import NovoAtendimentoScreen from './src/screens/NovoAtendimentoScreen';
import DashboardScreen from './src/screens/PedidosScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />

        <Stack.Screen
          name="NovoAtendimento"
          component={NovoAtendimentoScreen}
          options={{
            title: 'Novo Atendimento',
          }}
        />

        <Stack.Screen name="Pedidos" component={DashboardScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
